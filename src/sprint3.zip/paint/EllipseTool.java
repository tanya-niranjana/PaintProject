/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paint;

import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

/**
 * Allows the user to draw an ellipse 
 * 
 * @author tanya
 */
public class EllipseTool {
    
    public static void setupDrawing(DrawingArea drawingArea) {

        // turn off the eraser or pencil
        drawingArea.canvas.setOnMouseDragged(null);

        
        drawingArea.canvas.setOnMousePressed(
                new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent event) {

                drawingArea.startX = event.getX();
                drawingArea.startY = event.getY();
            }
        });

        drawingArea.canvas.setOnMouseReleased(
                new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent event) {

                double endX = event.getX();
                double endY = event.getY();

                double x =
                        Math.min(drawingArea.startX, endX);

                double y =
                        Math.min(drawingArea.startY, endY);

                double width =
                        Math.abs(endX - drawingArea.startX);

                double height =
                        Math.abs(endY - drawingArea.startY);

                drawingArea.gc.setLineWidth(
                        drawingArea.lineWidth
                );

                drawingArea.gc.setStroke(
                        drawingArea.lineColor
                );

                drawingArea.gc.strokeOval(
                        x,
                        y,
                        width,
                        height
                );

                drawingArea.modified = true;
            }
        });
    }
}
