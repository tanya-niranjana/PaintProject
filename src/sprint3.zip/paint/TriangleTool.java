/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paint;

import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

/**
 * Allows the user to draw a triangle 
 * 
 * @author tanya
 */
public class TriangleTool {
    
    /**
     * Sets up the mouse controls used to draw a triangle.
     *
     * @param drawingArea the drawing area where the triangle is drawn
     */
    public static void setupDrawing(DrawingArea drawingArea) {

        // turn off the eraser or pencil
        drawingArea.canvas.setOnMouseDragged(null);

        // save starting point when mouse is pressed. 
        drawingArea.canvas.setOnMousePressed(
                new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent event) {

                // starting location of the triangle
                drawingArea.startX = event.getX();
                drawingArea.startY = event.getY();
            }
        });

        // draw the triangle when mouse is released. 
        drawingArea.canvas.setOnMouseReleased(
                new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent event) {

                // ending location
                double endX = event.getX();
                double endY = event.getY();

                // find middle poisiton for the top point
                double middleX =
                        (drawingArea.startX + endX) / 2;

                // create x points for triangle
                double[] xPoints = {
                    middleX,
                    drawingArea.startX,
                    endX
                };
                
                // create y points for triangle
                double[] yPoints = {
                    drawingArea.startY,
                    endY,
                    endY
                };

                // apply line width and color 
                drawingArea.gc.setLineWidth(
                        drawingArea.lineWidth
                );
                drawingArea.gc.setStroke(
                        drawingArea.lineColor
                );

                // draw triangle
                drawingArea.gc.strokePolygon(
                        xPoints,
                        yPoints,
                        3
                );

                
                drawingArea.modified = true;
            }
        });
    }
}
