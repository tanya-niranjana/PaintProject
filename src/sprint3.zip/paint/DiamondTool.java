/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paint;

/**
 * Allows user to draw a diamond
 * 
 * @author tanya
 */
public class DiamondTool {
    
    /**
     * Sets up the mouse controls used to draw a diamond.
     *
     * @param drawingArea the drawing area where the diamond is drawn
     */
     public static void setupDrawing(
            DrawingArea drawingArea) {
         
        // turn off the eraser or pencil
        drawingArea.canvas.setOnMouseDragged(null);
        
        // save the starting point when the mouse is pressed
        drawingArea.canvas.setOnMousePressed(
                event -> {

           //starting x 
            drawingArea.startX =
                    event.getX();

            //starting y
            drawingArea.startY =
                    event.getY();
        });

        // draw diamond when mouse is released
        drawingArea.canvas.setOnMouseReleased(
                event -> {

            // get ending x and y 
            double endX = event.getX();
            double endY = event.getY();

            // find middle x and y
            double middleX =
                    (drawingArea.startX + endX) / 2;

            double middleY =
                    (drawingArea.startY + endY) / 2;

            // create x  and y points of diamond
            double[] xPoints = {
                middleX,
                endX,
                middleX,
                drawingArea.startX
            };

            double[] yPoints = {
                drawingArea.startY,
                middleY,
                endY,
                middleY
            };

            
            // apply the proper line width and color 
            drawingArea.gc.setLineWidth(
                    drawingArea.lineWidth
            );

            drawingArea.gc.setStroke(
                    drawingArea.lineColor
            );

            // draw diamond using 4 points 
            drawingArea.gc.strokePolygon(
                    xPoints,
                    yPoints,
                    4
            );

            // drawing has been modified.
            drawingArea.modified = true;
        });
    }
}
