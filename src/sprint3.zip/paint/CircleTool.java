/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paint;

import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

/**
 * Allows user to draw a circle
 * 
 * @author tanya
 */
public class CircleTool {
    
    /**
    * Sets up the mouse controls used to draw a circle 
    * 
    * @param drawingArea the drawing area where the circle is drawn
    */
    
    
    public static void setupDrawing(DrawingArea drawingArea) {

        // turn off the eraser or pencil
        drawingArea.canvas.setOnMouseDragged(null);
        
        // save the starting point when mouse is pressed
        drawingArea.canvas.setOnMousePressed(
                new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent event) {

                // get the starting location of the circle
                drawingArea.startX = event.getX();
                drawingArea.startY = event.getY();
            }
        });

        // draw the circle when the mouse is released
        drawingArea.canvas.setOnMouseReleased(
                new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent event) {

                // get the ending location
                double endX = event.getX();
                double endY = event.getY();

                // calculate width of dragged area
                double width =
                        Math.abs(endX - drawingArea.startX);

                // calculate height of dragged area
                double height =
                        Math.abs(endY - drawingArea.startY);
                
                // use the smaller of the two so circle stays a circle
                double size =
                        Math.min(width, height);

                // start circle at og mouse position
                double x = drawingArea.startX;
                double y = drawingArea.startY;

                // adjust x position if user drafts left
                if (endX < drawingArea.startX) {
                    x = drawingArea.startX - size;
                }

                //adjust y position if user drags up
                if (endY < drawingArea.startY) {
                    y = drawingArea.startY - size;
                }

                // apply the selected line width
                drawingArea.gc.setLineWidth(
                        drawingArea.lineWidth
                );

                // apply the selected line color
                drawingArea.gc.setStroke(
                        drawingArea.lineColor
                );

                // draw the circle
                drawingArea.gc.strokeOval(
                        x,
                        y,
                        size,
                        size
                );

                // mark drawing as changed so it needs to be saved. 
                drawingArea.modified = true;
            }
        });
    }
}
