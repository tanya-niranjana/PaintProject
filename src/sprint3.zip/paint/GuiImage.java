/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paint;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;

import java.io.File;

import javafx.scene.control.Slider;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import javafx.scene.control.ColorPicker;
import javafx.scene.paint.Color;

import javafx.scene.control.CheckMenuItem;

import javafx.scene.control.TabPane;
/**
 *Creates the main user interface for program
 * Sets up menu, drawing tools, color controls, line width,
 * tabs, and connects each feature to its function class 
 * 
 * @author tanya
 */
public class GuiImage extends Application {
    
    static File currentFile; //stores the image file currently being edit
    static byte[] imageData; // stores the original image file contents
    static DrawingArea drawingArea; // handles the image, canvas, and drawing tools
    
    
    /**
     * Creates and displays the main Paint window and all of its controls.
     *
     * @param stage the main Paint application window
     */    @Override
    public void start(Stage stage) {
        
        BorderPane root = new BorderPane(); // creates main layout
        
        Label colorLabel = new Label("Color: "); // put the drawing area in the center of the window 
        
        ColorPicker colorPicker = new ColorPicker(Color.BLACK);  
        
        Label colorText = new Label();
        
        // create the area that holds the image tabs
        TabPane tabPane = ImageTabs.createTabPane();

        // place the tabs in the center of the window
        root.setCenter(tabPane);

        // default black
        ColorTextLabel.update(
                Color.BLACK,
                colorText
        );

        
        // creates menu bar 
        MenuBar menuBar = new MenuBar(); 
        
        Menu fileMenu = new Menu("File");

        
        // create the file menu options
        MenuItem openItem = new MenuItem("Open");
        MenuItem saveItem = new MenuItem("Save");
        MenuItem saveAsItem = new MenuItem("Save As");
        MenuItem exitItem = new MenuItem("Exit");
        
        KeyboardShortcuts.setup(
            openItem,
            saveItem,
            saveAsItem,
            exitItem
        );
        
        // create the Shapes menu
        Menu shapesMenu = new Menu("Shapes");

        // diff shapes
        MenuItem lineItem = new MenuItem("Line");
        MenuItem squareItem = new MenuItem("Square");
        MenuItem rectangleItem = new MenuItem("Rectangle");
        MenuItem circleItem = new MenuItem("Circle");
        MenuItem ellipseItem = new MenuItem("Ellipse");
        MenuItem triangleItem = new MenuItem("Triangle");
        MenuItem diamondItem = new MenuItem("Diamond");
        
        // additional drawing options
        MenuItem pencilItem = new MenuItem("Pencil");
        MenuItem eraserItem = new MenuItem("Eraser");
        MenuItem colorGrabberItem = new MenuItem("Color Grabber");

        // dashed lines yes or no
        CheckMenuItem dashedItem = new CheckMenuItem("Dashed Outline");
        
        // add everything to shape menu
        shapesMenu.getItems().addAll(
            lineItem,
            pencilItem,
            eraserItem,
            colorGrabberItem,
            squareItem,
            rectangleItem,
            circleItem,
            ellipseItem,
            triangleItem,
            diamondItem,
            dashedItem
        );
        
        // create the help menu and its options 
        Menu helpMenu = new Menu("Help");
        
        MenuItem helpItem = new MenuItem("Help");
        MenuItem aboutItem = new MenuItem("About");
       
        
        // adds all four menu items
        fileMenu.getItems().addAll(
                openItem,
                saveItem,
                saveAsItem,
                exitItem
        );
        
        // adds two help menu items
        helpMenu.getItems().addAll(
            helpItem,
            aboutItem
        );
        
        // create the Image Menu and resize option
        Menu imageMenu = new Menu("Image");
        
        MenuItem resizeItem = new MenuItem("Resize Drawing Area");
        
        imageMenu.getItems().add(resizeItem);
        
        // puts inside menu bar 
        menuBar.getMenus().addAll(
            fileMenu,
            imageMenu,
            shapesMenu,
            helpMenu
            
        );

        // choose straight line tool
        lineItem.setOnAction(event -> {
            SetUpDrawing.setupDrawing(drawingArea);
        });

        // choose square tool
        squareItem.setOnAction(event -> {
            SqaureTool.setupDrawing(drawingArea);
        });

        // choose rectangle tool
        rectangleItem.setOnAction(event -> {
            RectangleTool.setupDrawing(drawingArea);
        });

        // choose circle tool
        circleItem.setOnAction(event -> {
            CircleTool.setupDrawing(drawingArea);
        });

        // choose ellipse tool
        ellipseItem.setOnAction(event -> {
            EllipseTool.setupDrawing(drawingArea);
        });

        // choose triangle tool
        triangleItem.setOnAction(event -> {
            TriangleTool.setupDrawing(drawingArea);
        });
        
        // choose pencil drawing tool
        pencilItem.setOnAction(event -> {
            PencilTool.setupDrawing(drawingArea);
        });

        // choose eraser tool
        eraserItem.setOnAction(event -> {
            EraserTool.setupDrawing(drawingArea);
        });

        // choose color grabber tool
        colorGrabberItem.setOnAction(event -> {
            ColorGrabber.setup(
                    drawingArea,
                    colorPicker,
                    colorText
            );
        });
        
        // choose the diamond drawing tool
        diamondItem.setOnAction(event -> {
            DiamondTool.setupDrawing(drawingArea);
        });
        
        // turn dash lines on or off 
        dashedItem.setOnAction(event -> {

            // if selected 
            if (dashedItem.isSelected()) {

                DashedOutline.turnOn(
                        drawingArea
                );

            } else {
                
                // return to normal if not 
                DashedOutline.turnOff(
                        drawingArea
                );
            }
        });
        
        // create the slide used to change line width
        Label widthLabel = new Label("Line Width"); 
        Slider lineWidthSlider = new Slider(1,20,3);
        
        Label pixelLabel = new Label("3 px");

        // connect the slider to the line width controls
        WidthControls.setup(
                lineWidthSlider,
                pixelLabel,
                drawingArea
        );
        
        
        // show the numbers and tick marks on the line width slider
        lineWidthSlider.setShowTickLabels(true);
        lineWidthSlider.setShowTickMarks(true);
        
        
        // update the drawing line width whenever the slider changes 
        lineWidthSlider.valueProperty().addListener(
            (obserable, oldValue, newValue) -> {
                drawingArea.setLineWidth(newValue.doubleValue());
             }
        );
        
        // put the drawing controls together in one toolbar
        HBox tools = new HBox(
            10,
            widthLabel, 
            lineWidthSlider,
            pixelLabel,
            colorLabel,
            colorPicker,
            colorText
        );
        
        // place the menu bar and drawing tools at the top of the window
        VBox topArea = new VBox(
            menuBar,
            tools
        );
        
        root.setTop(topArea);
        
        // update the drawing color when the user chooses a new color
        colorPicker.setOnAction(event -> {

        // update color used for drawing
        drawingArea.setLineColor(
                colorPicker.getValue()
        );
        
        // update the color info shown to user
        ColorTextLabel.update(
                colorPicker.getValue(),
                colorText
            );
        });
        
       // connect each menu item to its function file
      
        HelpFunction.setup(helpItem);

        AboutFunction.setup(aboutItem);

        OpenImage.setup(
                openItem,
                stage
        );

        ResizeFunction.setup(
                resizeItem
        );

        SaveFunction.setup(
                saveItem
        );

        SaveAsFunction.setup(
                saveAsItem,
                stage
        );

        ExitFunction.setup(
                exitItem,
                stage
        );

        CloseFunction.setup(
                stage,
                saveItem
        );

        
        
        // creates the scene 
        Scene scene = new Scene(root, 800, 600);
        
        // set window title and display the program
        stage.setTitle("Paint");
        stage.setScene(scene);
        stage.show();
    }
    
    
    /**
     * Starts the Paint application.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
    launch(args);
}

}