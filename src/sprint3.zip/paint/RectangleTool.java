/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paint;

import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
/**
 * Allows user to draw a rectangle
 * 
 * @author tanya
 */
public class RectangleTool {
    
    /**
    * sets up the mouse controls used to draw a rectangle
    * 
    * @param drawingArea the drawing area where the rectangle is drawn
    */
    public static void setupDrawing(DrawingArea drawingArea) {

        // turn off the eraser or pencil
        drawingArea.canvas.setOnMouseDragged(null);

        // save the starting point when the mouse is pressed. 
        drawingArea.canvas.setOnMousePressed(
                new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent event) {
                
                // get the starting location of the rectangle
                drawingArea.startX = event.getX();
                drawingArea.startY = event.getY();
            }
        });

        // draw the rectangle when the mouse is released
        drawingArea.canvas.setOnMouseReleased(
                new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent event) {

                // get ending location
                double endX = event.getX();
                double endY = event.getY();

                // find the left side of rectangle
                double x =
                        Math.min(drawingArea.startX, endX);

                // find top side of rectangle
                double y =
                        Math.min(drawingArea.startY, endY);

                // calculate the rectangle width and height
                double width =
                        Math.abs(endX - drawingArea.startX);
                double height =
                        Math.abs(endY - drawingArea.startY);

                // apply line width and color
                drawingArea.gc.setLineWidth(
                        drawingArea.lineWidth
                );
                drawingArea.gc.setStroke(
                        drawingArea.lineColor
                );

                // draw the rectangle
                drawingArea.gc.strokeRect(
                        x,
                        y,
                        width,
                        height
                );

                // mark the drawing as changed so it needs to be saved. 
                drawingArea.modified = true;
            }
        });
    }
}
