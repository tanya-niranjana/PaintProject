/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paint;

import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

/**
 * Allows user to draw a square
 * 
 * @author tanya
 */
public class SqaureTool {
    
    /**
     * Sets up the mouse controls used to draw a square.
     *
     * @param drawingArea the drawing area where the square is drawn
     */
     public static void setupDrawing(DrawingArea drawingArea) {

         
        // turn off the eraser or pencil
        drawingArea.canvas.setOnMouseDragged(null);
 
        // save the starting point when the mouse is pressed
        drawingArea.canvas.setOnMousePressed(
                new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent event) {

                // get the starting location of the square. 
                drawingArea.startX = event.getX();
                drawingArea.startY = event.getY();
            }
        });

        // draw the squarre when mouse is released. 
        drawingArea.canvas.setOnMouseReleased(
                new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent event) {

                // ending location
                double endX = event.getX();
                double endY = event.getY();

                // calculate width and height
                double width =
                        Math.abs(endX - drawingArea.startX);

                double height =
                        Math.abs(endY - drawingArea.startY);
                // use smaller value so shape stays a square. 
                double size =
                        Math.min(width, height);

                // start square at og mouse position
                double x = drawingArea.startX;
                double y = drawingArea.startY;

                
                // adjust the x position if the user drags left
                if (endX < drawingArea.startX) {
                    x = drawingArea.startX - size;
                }

                // adjust y if dragged up
                if (endY < drawingArea.startY) {
                    y = drawingArea.startY - size;
                }

                // set line width and color
                drawingArea.gc.setLineWidth(
                        drawingArea.lineWidth
                );
                drawingArea.gc.setStroke(
                        drawingArea.lineColor
                );

                // draw the square 
                drawingArea.gc.strokeRect(
                        x,
                        y,
                        size,
                        size
                );

                // mark drawing as changes so it needs to be saved. 
                drawingArea.modified = true;
            }
        });
    }
}
