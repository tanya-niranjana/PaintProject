/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paint;

import javafx.scene.SnapshotParameters;
import javafx.scene.image.WritableImage;

/**
 * Creates an edited image contain both og and 
 * and any drawings added by user
 * 
 * @author tanya
 */
public class GetEditedImage {
    
     /**
     * Takes a snapshot of the entire drawing area and returns it
     * as one image that can be saved.
     *
     * @param drawingArea the drawing area containing the image and drawings
     * @return the edited image containing everything in the drawing area
     */
    public static WritableImage getEditedImage(DrawingArea drawingArea) {
        
        // gets the current size of drawing
        int width = (int) drawingArea.drawingPane.getWidth();
        int height = (int) drawingArea.drawingPane.getHeight();
        
        // create any empty image that will hold the edited pic
        WritableImage editedImage = 
            new WritableImage(width,height);
        
        // take a snapshot of everything in the drawing area. 
        drawingArea.drawingPane.snapshot(
            new SnapshotParameters(),
            editedImage
        );
        
        // return the image so it can be saved
        return editedImage;
    }
}
