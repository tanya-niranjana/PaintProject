/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paint;

import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

/**
 *
 * sets up the straight line drawing tool
 * 
 * @author tanya
 */
public class SetUpDrawing {
    /**
     *
     * sets up the mouse controls used to draw a straight line
     * 
     * @param drawingArea the drawing area where the line is drawn
     */
    public static void setupDrawing(DrawingArea drawingArea){
        
        drawingArea.canvas.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                
                // get the location where the user started the line
                drawingArea.startX = event.getX();
                drawingArea.startY = event.getY();
            }
        });
        
        // draw a line when the user releases the mouse
        drawingArea.canvas.setOnMouseReleased(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                
                // get the ending point of a line
                double endX = event.getX();
                double endY = event.getY();
               
                
                // apply the selected line width and color
                drawingArea.gc.setLineWidth(drawingArea.lineWidth);
                drawingArea.gc.setStroke(drawingArea.lineColor);
                
                
                // draw the line from starting point to ending
                drawingArea.gc.strokeLine(
                    drawingArea.startX,
                    drawingArea.startY,
                    endX,
                    endY
                );
                
                // mark the drawing as changed so the program knows it needs to be saved
                drawingArea.modified = true;
            }
        });
    }
}

