/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paint;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;


/**
 * Creates and manages the drawing area
 * 
 * Holds the image, canvas, drawing settings, and modified status
 * 
 * @author tanya
 */
public class DrawingArea {
    ImageView imageView; // displays the image that the user opens
    Canvas canvas; // Canvas placed over the image so the user can draw
    Pane drawingPane; // Holds the image and canvas together
    ScrollPane scrollPane; // Allows the user to scroll around large images
    
    GraphicsContext gc; // used to draw lines on the canvas
   
    // stores where the user first clicks to start a line
    double startX; 
    double startY;
    
    double lineWidth =3;// default line width
    
    Color lineColor = Color.BLACK; // default drawing color
    
    boolean modified = false; // keeps track of whether the image has unsaved changes
   

/**
     * Creates and sets up the drawing area.
     */
    public DrawingArea() {
        
        imageView = new ImageView(); // creates the image display
        
        canvas = new Canvas(); // creates the transparent drawing canvas
        
        gc = canvas.getGraphicsContext2D(); // gets the tool used to draw on canvas
        
        drawingPane = new Pane();// creates the area that holds both the image and canvas
        
        // make any extra resized drawing space white 
        drawingPane.setStyle("-fx-background-color: white;");
        
        //Image goes first, canvas goes on top
        drawingPane.getChildren().addAll(imageView, canvas);
        
        //places the drawing area inside a scrollable window
        scrollPane = new ScrollPane(drawingPane);
        
        //allows large images to be moved around inside the scorll pane
        scrollPane.setPannable(true);
        
        // turns on the mouse drawing control
    }
    
    /**
     * Displays an image in the drawing area.
     *
     * @param image the image that will be displayed
     */
    
     public void setImage(Image image){
        SetImage.setImage(this, image);
    }
    
    
 /**
     * Returns the scrollable drawing area so it can be displayed in GuiImage.
     *
     * @return the ScrollPane containing the drawing area
     */
    public ScrollPane getView() {
        return scrollPane;
    }
    
    /**
     * Updates the width used for new lines and shapes.
     *
     * @param width the new line width
     */
    public void setLineWidth(double width){
        SetLineWidth.setLineWidth(this, width);
    }
    
    /**
     * Updates the color used for new lines and shapes.
     *
     * @param color the new drawing color
     */
    public void setLineColor(Color color) {
        SetLineColor.setLineColor(this, color);
    }
    
    /**
     * Creates one image containing the original image and current drawings.
     *
     * @return the edited image
     */
    public WritableImage getEditedImage() {
        return GetEditedImage.getEditedImage(this);
    }
    
     /**
     * Checks whether the image has unsaved changes.
     *
     * @return true if the image has been modified
     */
    public boolean isModified() {
        return IsModified.isModified(this);
    }

     /**
     * Checks whether the image has unsaved changes.
     *
     * @return true if the image has been modified
     */
    public void resizeDrawingArea(double width, double height) {
        ResizedDrawingArea.resizeDrawingArea(this, width, height);
    }
    
     /**
     * Marks the current image as saved.
     */
    public void markSaved() {
        MarkSaved.markSaved(this);
    }
}

    
    
